"use client";

import React from "react";
import { Place } from "@/types/place";
import { GOOGLE_MAPS_EMBED_API_KEY } from "@/lib/constants";

interface InlineEmbeddedMapProps {
  searchQuery?: string | null;
  places: Place[];
  selectedPlaceId: string | null;
  onExpandMap: () => void;
}

export function InlineEmbeddedMap({
  searchQuery,
  places,
  selectedPlaceId,
  onExpandMap,
}: InlineEmbeddedMapProps) {
  if (!GOOGLE_MAPS_EMBED_API_KEY) {
    return (
      <div className="mt-3 flex flex-col items-center justify-center rounded-2xl border border-dashed border-amber-300/80 bg-amber-50/50 p-4 text-center dark:border-amber-900/50 dark:bg-amber-950/30">
        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
          Add NEXT_PUBLIC_GOOGLE_MAPS_EMBED_API_KEY to display the embedded map.
        </p>
      </div>
    );
  }

  const selectedPlace = places.find((p) => p.place_id === selectedPlaceId);

  // Construct Embed API URL safely using URLSearchParams
  const baseUrl = "https://www.google.com/maps/embed/v1";
  const params = new URLSearchParams({
    key: GOOGLE_MAPS_EMBED_API_KEY,
  });

  let embedEndpoint = "search";
  let externalMapsUrl = "https://www.google.com/maps";

  if (selectedPlace) {
    embedEndpoint = "place";
    params.set("q", `place_id:${selectedPlace.place_id}`);
    externalMapsUrl = selectedPlace.google_maps_url;
  } else if (searchQuery && searchQuery.trim()) {
    embedEndpoint = "search";
    params.set("q", searchQuery.trim());
    externalMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      searchQuery.trim()
    )}`;
  } else if (places.length > 0) {
    embedEndpoint = "place";
    params.set("q", `place_id:${places[0].place_id}`);
    externalMapsUrl = places[0].google_maps_url;
  }

  const iframeSrc = `${baseUrl}/${embedEndpoint}?${params.toString()}`;

  return (
    <div className="mt-3 flex flex-col gap-2.5">
      <div className="relative overflow-hidden rounded-2xl border border-zinc-200/80 bg-zinc-100 shadow-xs dark:border-zinc-800/80 dark:bg-zinc-900">
        <iframe
          title="Google Maps Result"
          src={iframeSrc}
          className="h-[260px] w-full sm:h-[300px] border-0"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
      </div>

      <div className="flex items-center justify-between text-xs pt-0.5">
        <button
          type="button"
          onClick={onExpandMap}
          className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 px-3 py-1.5 font-bold text-blue-700 shadow-2xs transition-all hover:scale-102 hover:from-blue-100 hover:to-indigo-100 active:scale-98 dark:from-blue-950/60 dark:to-indigo-950/60 dark:text-blue-300 dark:hover:from-blue-900/60 dark:hover:to-indigo-900/60"
        >
          <svg
            className="h-3.5 w-3.5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
            />
          </svg>
          Expand interactive map
        </button>

        <a
          href={externalMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 font-semibold text-zinc-600 hover:text-blue-600 transition-colors dark:text-zinc-400 dark:hover:text-blue-400"
        >
          Open in Google Maps &rarr;
        </a>
      </div>
    </div>
  );
}
