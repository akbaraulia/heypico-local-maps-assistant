"use client";

import React, { useEffect, useRef, useState } from "react";
import { importLibrary, setOptions } from "@googlemaps/js-api-loader";
import { Place } from "@/types/place";
import {
  DEFAULT_MAP_CENTER,
  DEFAULT_MAP_ZOOM,
  FOCUSED_MAP_ZOOM,
  GOOGLE_MAPS_API_KEY,
} from "@/lib/constants";
import { MapFallback } from "./MapFallback";
import { SelectedPlaceOverlay } from "./SelectedPlaceOverlay";
import { formatRating } from "@/lib/formatters";

interface PlacesMapProps {
  places: Place[];
  selectedPlaceId: string | null;
  onSelectPlace: (placeId: string | null) => void;
}

export function PlacesMap({
  places,
  selectedPlaceId,
  onSelectPlace,
}: PlacesMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<Map<string, google.maps.Marker>>(new Map());
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);

  const [loadError, setLoadError] = useState<string | null>(
    !GOOGLE_MAPS_API_KEY
      ? "Add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to display the interactive map."
      : null
  );
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  // Initialize Map API
  useEffect(() => {
    if (!GOOGLE_MAPS_API_KEY) return;

    setOptions({
      key: GOOGLE_MAPS_API_KEY,
      v: "weekly",
    });

    Promise.all([importLibrary("maps"), importLibrary("places")])
      .then(() => {
        if (!mapRef.current || googleMapRef.current) return;

        const map = new google.maps.Map(mapRef.current, {
          center: DEFAULT_MAP_CENTER,
          zoom: DEFAULT_MAP_ZOOM,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: true,
          zoomControl: true,
          styles: [
            {
              featureType: "poi",
              elementType: "labels",
              stylers: [{ visibility: "off" }],
            },
          ],
        });

        googleMapRef.current = map;
        infoWindowRef.current = new google.maps.InfoWindow();
        setIsLoaded(true);
      })
      .catch((err) => {
        console.error("Failed to load Google Maps API", err);
        setLoadError(
          "Failed to load Google Maps JavaScript API. Please check your API key and network."
        );
      });
  }, []);

  // Sync Markers with Places
  useEffect(() => {
    const map = googleMapRef.current;
    if (!isLoaded || !map) return;

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.setMap(null));
    markersRef.current.clear();

    const validPlaces = places.filter(
      (p) =>
        typeof p.lat === "number" &&
        typeof p.lng === "number" &&
        !Number.isNaN(p.lat) &&
        !Number.isNaN(p.lng)
    );

    if (validPlaces.length === 0) {
      map.setCenter(DEFAULT_MAP_CENTER);
      map.setZoom(DEFAULT_MAP_ZOOM);
      if (infoWindowRef.current) {
        infoWindowRef.current.close();
      }
      return;
    }

    const bounds = new google.maps.LatLngBounds();

    validPlaces.forEach((place, index) => {
      const position = { lat: place.lat, lng: place.lng };
      bounds.extend(position);

      const marker = new google.maps.Marker({
        position,
        map,
        title: place.name,
        label: {
          text: String(index + 1),
          color: "#ffffff",
          fontWeight: "bold",
          fontSize: "12px",
        },
      });

      marker.addListener("click", () => {
        onSelectPlace(place.place_id);
      });

      markersRef.current.set(place.place_id, marker);
    });

    if (validPlaces.length === 1) {
      map.setCenter({ lat: validPlaces[0].lat, lng: validPlaces[0].lng });
      map.setZoom(FOCUSED_MAP_ZOOM);
    } else {
      map.fitBounds(bounds);

      const listener = google.maps.event.addListenerOnce(map, "idle", () => {
        if (map.getZoom() && (map.getZoom() as number) > 16) {
          map.setZoom(16);
        }
      });

      return () => {
        google.maps.event.removeListener(listener);
      };
    }
  }, [isLoaded, places, onSelectPlace]);

  // Handle Selected Place state
  useEffect(() => {
    const map = googleMapRef.current;
    const infoWindow = infoWindowRef.current;
    if (!isLoaded || !map || !infoWindow) return;

    if (!selectedPlaceId) {
      infoWindow.close();
      return;
    }

    const place = places.find((p) => p.place_id === selectedPlaceId);
    const marker = markersRef.current.get(selectedPlaceId);

    if (place && marker) {
      map.panTo({ lat: place.lat, lng: place.lng });
      if ((map.getZoom() as number) < 14) {
        map.setZoom(FOCUSED_MAP_ZOOM);
      }

      const contentString = `
        <div style="padding: 4px; font-family: system-ui, -apple-system, sans-serif; max-width: 220px;">
          <h4 style="margin: 0 0 4px 0; font-size: 14px; font-weight: 700; color: #111827;">
            ${escapeHtml(place.name)}
          </h4>
          <p style="margin: 0 0 6px 0; font-size: 11px; color: #6b7280; line-height: 1.3;">
            ${escapeHtml(place.address || "Address unavailable")}
          </p>
          <div style="display: flex; align-items: center; justify-content: space-between; font-size: 12px;">
            <span style="font-weight: 600; color: #d97706;">★ ${formatRating(place.rating)}</span>
            <a href="${escapeHtml(place.directions_url)}" target="_blank" rel="noopener noreferrer" style="color: #2563eb; font-weight: 600; text-decoration: none; margin-left: 8px;">Directions &rarr;</a>
          </div>
        </div>
      `;

      infoWindow.setContent(contentString);
      infoWindow.open(map, marker);
    }
  }, [isLoaded, selectedPlaceId, places]);

  if (!GOOGLE_MAPS_API_KEY || loadError) {
    return <MapFallback message={loadError || undefined} />;
  }

  const selectedPlace = places.find((p) => p.place_id === selectedPlaceId);

  return (
    <div className="relative h-full w-full overflow-hidden rounded-2xl border border-zinc-200 bg-zinc-100 shadow-2xs dark:border-zinc-800 dark:bg-zinc-900">
      <div ref={mapRef} className="h-full w-full min-h-[350px]" />
      {selectedPlace && (
        <SelectedPlaceOverlay
          place={selectedPlace}
          onClose={() => onSelectPlace(null)}
        />
      )}
    </div>
  );
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
