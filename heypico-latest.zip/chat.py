import math
import re

from fastapi import Request

from app.core.exceptions import OllamaInvalidResponseError
from app.schemas.chat import (
    ChatIntent,
    ChatLanguage,
    ChatRequest,
    ChatResponse,
    IntentAnalysis,
    ParserAction,
    RefinementFlags,
    RequestedDetail,
    SearchContext,
    PlaceReference,
)
from app.services.google_places import GooglePlacesService
from app.services.ollama import OllamaService
from app.schemas.place import Place

_PLACE_KEYWORDS = (
    "restoran",
    "rumah sakit",
    "hotel",
    "atm",
    "tempat makan",
    "kafe",
    "cafe",
    "coffee shop",
    "tempat wisata",
    "apotek",
    "spbu",
    "restaurant",
    "hospital",
    "pharmacy",
    "gas station",
    "places to visit",
    "bakso",
    "mie ayam",
)
_INDONESIAN_MARKERS = (
    "halo",
    "hai",
    "kamu",
    "siapa",
    "cari",
    "terdekat",
    "dekat sini",
    "rumah sakit",
    "tempat",
    "apotek",
    "restoran",
    "murah",
    "bagus",
    "buka",
)
_GENERAL_MARKERS = (
    "halo",
    "hai",
    "hello",
    "kamu bisa apa",
    "what can you do",
    "siapa kamu",
    "who are you",
    "makasih",
    "terima kasih",
    "thank you",
    "thanks",
)
_LOCATION_PATTERNS = (
    re.compile(r"\b(?:di|sekitar|dekat)\s+(.+)$", re.IGNORECASE),
    re.compile(r"\b(?:near|in|around)\s+(.+)$", re.IGNORECASE),
)
_NON_LOCATIONS = {
    "me",
    "here",
    "nearby",
    "sini",
    "saya",
    "aku",
    "mana",
    "situ",
}
_ACTION_PREFIX = re.compile(
    r"^(?:tolong\s+)?(?:cari(?:kan)?|temukan|find|show me)\s+",
    re.IGNORECASE,
)

_CHEAPER_TRIGGERS = (
    "murah",
    "lebih murah",
    "budget",
    "affordable",
    "inexpensive",
    "cheaper",
    "ekonomis",
    "ramah kantong",
)
_RATED_TRIGGERS = (
    "rating tertinggi",
    "paling bagus",
    "review terbaik",
    "highest rated",
    "best reviewed",
)
_OPEN_TRIGGERS = (
    "masih buka",
    "buka sekarang",
    "open now",
    "currently open",
)
_ALT_TRIGGERS = (
    "opsi lain",
    "cari yang lain",
    "yang lain",
    "anything else",
    "show more",
)
_NEAREST_TRIGGERS = ("nearest", "closest", "terdekat", "paling dekat")
_OPEN_24_TRIGGERS = ("24 jam", "24 hours", "open all night")


class ChatService:
    def __init__(
        self,
        ollama: OllamaService,
        google_places: GooglePlacesService,
    ) -> None:
        self._ollama = ollama
        self._google_places = google_places

    async def chat(self, request: ChatRequest) -> ChatResponse:
        has_coordinates = request.user_lat is not None
        try:
            analysis = await self._ollama.parse_intent(
                request.message,
                has_coordinates=has_coordinates,
                preferred_language=request.language,
                history=request.history,
                context=request.context,
            )
        except OllamaInvalidResponseError:
            analysis = _fallback_analysis(
                request.message,
                has_coordinates=has_coordinates,
                context=request.context,
            )
            if analysis is None:
                raise

        if _is_obvious_general(request.message):
            analysis = IntentAnalysis(
                action=ParserAction.GENERAL,
                search_terms=None,
                location=None,
                language=_detect_language(request.message.casefold()),
                requested_result_count=None,
                place_reference=None,
                selected_result_index=None,
                requested_detail=RequestedDetail.NONE,
                refinements=RefinementFlags(),
                requires_clarification=False,
            )

        response_language = request.language or analysis.language

        if analysis.action == ParserAction.GENERAL:
            reply = _acknowledgement_reply(request.message, response_language)
            if reply is None:
                try:
                    reply = await self._ollama.general_reply(
                        request.message,
                        response_language,
                        history=request.history,
                    )
                except OllamaInvalidResponseError:
                    reply = _safe_general_fallback(
                        request.message, response_language
                    ) or _generic_general_fallback(response_language)
            return ChatResponse(
                message=reply,
                intent="general",
                requires_location=False,
                search_query=None,
                places=[],
                context=request.context,
            )

        if analysis.action == ParserAction.UNSUPPORTED:
            return ChatResponse(
                message=_unsupported_message(response_language),
                intent="unsupported",
                requires_location=False,
                search_query=None,
                places=[],
                context=request.context,
            )

        if analysis.action in {ParserAction.SELECT_PLACE, ParserAction.GET_PLACE_DETAILS}:
            matched = _resolve_place_reference(
                request.context,
                analysis.place_reference,
                analysis.selected_result_index,
            )
            if matched is None:
                return ChatResponse(
                    message=_unmatched_place_message(response_language),
                    intent="place_detail",
                    requires_location=False,
                    search_query=None,
                    places=[],
                    context=request.context,
                )
            place = await self._google_places.get_place_details(matched.place_id)
            return ChatResponse(
                message=_detail_message(place, analysis.requested_detail, response_language),
                intent="place_detail",
                requires_location=False,
                search_query=None,
                places=[place],
                context=request.context,
                selected_place_id=place.place_id,
            )

        intent: ChatIntent = (
            "place_search"
            if analysis.action == ParserAction.SEARCH_PLACES
            else "place_refinement"
        )
        last_terms = request.context.last_search_terms if request.context else None
        last_loc = request.context.last_location if request.context else None
        search_terms = analysis.search_terms
        location = _verified_location(analysis.location, request.message)
        if location is None:
            location = _extract_explicit_location(request.message)

        if intent == "place_refinement":
            search_terms = search_terms or last_terms
            location = location or last_loc
            if not search_terms:
                return ChatResponse(
                    message=_missing_refinement_context_message(
                        analysis.refinements, response_language
                    ),
                    intent="place_refinement",
                    requires_location=False,
                    search_query=None,
                    places=[],
                    context=request.context,
                )

        if location is None and not has_coordinates:
            return ChatResponse(
                message=_clarification_message(response_language),
                intent=intent,
                requires_location=True,
                search_query=None,
                places=[],
                context=request.context,
            )

        effective_terms = search_terms or request.message
        lowered_terms = effective_terms.casefold()
        if analysis.refinements.cheaper and not any(
            term in lowered_terms for term in ("murah", "cheap", "affordable", "inexpensive")
        ):
            effective_terms = f"{effective_terms} {'murah' if response_language == 'id' else 'affordable'}"
        if analysis.refinements.family_friendly and "family" not in lowered_terms:
            effective_terms = f"{effective_terms} family friendly"
        if analysis.refinements.open_24_hours and "24" not in lowered_terms:
            effective_terms = f"{effective_terms} 24 jam"

        search_query = _build_search_query(effective_terms, location, analysis.language)
        result_count = analysis.requested_result_count or 5
        result_count = max(1, min(20, result_count))
        price_levels = (
            ["PRICE_LEVEL_INEXPENSIVE"]
            if analysis.refinements.cheaper
            else None
        )
        open_now_filter = analysis.refinements.open_now

        places = await self._google_places.search_text(
            search_query,
            user_lat=request.user_lat,
            user_lng=request.user_lng,
            price_levels=price_levels,
            open_now=open_now_filter,
            max_results=result_count,
        )

        if analysis.refinements.cheaper and not places:
            places = await self._google_places.search_text(
                search_query,
                user_lat=request.user_lat,
                user_lng=request.user_lng,
                price_levels=["PRICE_LEVEL_INEXPENSIVE", "PRICE_LEVEL_MODERATE"],
                open_now=open_now_filter,
                max_results=result_count,
            )

        if analysis.refinements.open_now:
            places = [place for place in places if place.open_now is True]
        if analysis.refinements.open_24_hours:
            places = [place for place in places if _is_open_24_hours(place)]
        if analysis.refinements.higher_rated:
            places.sort(
                key=lambda p: (p.rating or 0.0, p.user_rating_count or 0),
                reverse=True,
            )
        if analysis.refinements.alternatives and request.context and request.context.last_place_ids:
            previous_ids = set(request.context.last_place_ids)
            alternatives = [place for place in places if place.place_id not in previous_ids]
            if alternatives:
                places = alternatives

        reference_lat = request.user_lat
        reference_lng = request.user_lng
        if analysis.refinements.nearest:
            if reference_lat is None and request.context:
                reference_lat = request.context.reference_lat
                reference_lng = request.context.reference_lng
            if reference_lat is None and location:
                reference = await self._google_places.search_text(location, max_results=1)
                if reference:
                    reference_lat, reference_lng = reference[0].lat, reference[0].lng
            if reference_lat is None or reference_lng is None:
                return ChatResponse(
                    message=_nearest_clarification_message(response_language),
                    intent="place_refinement",
                    requires_location=True,
                    search_query=None,
                    places=[],
                    context=request.context,
                )
            for place in places:
                place.distance_meters = _haversine_meters(
                    reference_lat, reference_lng, place.lat, place.lng
                )
            places.sort(
                key=lambda p: (
                    p.distance_meters if p.distance_meters is not None else float("inf"),
                    -(p.rating or 0.0),
                    -(p.user_rating_count or 0),
                )
            )

        places = places[:result_count]
        if analysis.refinements.open_24_hours and not places:
            message = _no_24_hour_message(response_language)
        elif analysis.refinements.cheaper:
            message = _cheaper_result_message(
                len(places), search_terms or "", location, response_language
            )
        elif analysis.refinements.higher_rated:
            message = _higher_rated_message(response_language)
        else:
            message = _result_message(len(places), search_query, response_language)

        new_context = SearchContext(
            last_intent=intent,
            last_search_terms=search_terms,
            last_location=location,
            last_search_query=search_query,
            last_place_ids=[place.place_id for place in places[:10]],
            last_places=[
                {
                    "place_id": place.place_id,
                    "name": place.name,
                    "lat": place.lat,
                    "lng": place.lng,
                }
                for place in places[:10]
            ],
            reference_lat=reference_lat,
            reference_lng=reference_lng,
        )
        return ChatResponse(
            message=message,
            intent=intent,
            requires_location=False,
            search_query=search_query,
            places=places,
            context=new_context,
        )



def get_chat_service(request: Request) -> ChatService:
    settings = request.app.state.settings
    client = request.app.state.http_client
    return ChatService(
        ollama=OllamaService(settings=settings, client=client),
        google_places=GooglePlacesService(settings=settings, client=client),
    )


def _fallback_analysis(
    message: str,
    *,
    has_coordinates: bool,
    context: SearchContext | None = None,
) -> IntentAnalysis | None:
    lowered = message.casefold()
    language = _detect_language(lowered)

    # Check for refinement triggers if context exists
    if context and (context.last_search_terms or context.last_location):
        refinements = RefinementFlags(
            cheaper=any(t in lowered for t in _CHEAPER_TRIGGERS),
            higher_rated=any(t in lowered for t in _RATED_TRIGGERS),
            open_now=any(t in lowered for t in _OPEN_TRIGGERS),
            open_24_hours=any(t in lowered for t in _OPEN_24_TRIGGERS),
            nearest=any(t in lowered for t in _NEAREST_TRIGGERS),
            alternatives=any(t in lowered for t in _ALT_TRIGGERS),
        )
        requested_count = _extract_requested_count(lowered)

        if refinements.any_enabled() or requested_count is not None:
            location = _extract_explicit_location(message) or context.last_location
            terms = _strip_action_and_location(message)
            if not terms or terms in _CHEAPER_TRIGGERS or terms in _RATED_TRIGGERS:
                terms = context.last_search_terms

            return IntentAnalysis(
                action=ParserAction.REFINE_SEARCH,
                search_terms=terms,
                location=location,
                language=language,
                requested_result_count=requested_count,
                place_reference=None,
                selected_result_index=None,
                requested_detail=RequestedDetail.NONE,
                refinements=refinements,
                requires_clarification=False,
            )

    if not any(keyword in lowered for keyword in _PLACE_KEYWORDS):
        return None

    location = _extract_explicit_location(message)
    terms = _strip_action_and_location(message)
    if not terms:
        return None

    return IntentAnalysis(
        action=ParserAction.SEARCH_PLACES,
        search_terms=terms,
        location=location,
        language=language,
        requested_result_count=None,
        place_reference=None,
        selected_result_index=None,
        requested_detail=RequestedDetail.NONE,
        refinements=RefinementFlags(),
        requires_clarification=location is None and not has_coordinates,
    )


def _extract_requested_count(lowered: str) -> int | None:
    digit_match = re.search(r"\b(\d{1,2})\b", lowered)
    if digit_match:
        return max(1, min(20, int(digit_match.group(1))))
    words = {
        "one": 1, "two": 2, "three": 3, "five": 5, "ten": 10,
        "satu": 1, "dua": 2, "tiga": 3, "lima": 5, "sepuluh": 10,
    }
    for word, value in words.items():
        if re.search(rf"\b{word}\b", lowered):
            return value
    return None


def _detect_language(lowered_message: str) -> ChatLanguage:
    if re.search(r"\b(?:bro|brow)\b", lowered_message):
        return "id"
    if any(marker in lowered_message for marker in _INDONESIAN_MARKERS):
        return "id"
    return "en"


def _is_obvious_general(message: str) -> bool:
    lowered = message.casefold()
    has_general_marker = any(marker in lowered for marker in _GENERAL_MARKERS)
    has_general_marker = has_general_marker or bool(
        re.search(r"\b(?:hi|hai|halo|hello|bro|brow)\b", lowered)
    )
    has_place_keyword = any(keyword in lowered for keyword in _PLACE_KEYWORDS)
    return has_general_marker and not has_place_keyword


def _acknowledgement_reply(
    message: str, language: ChatLanguage
) -> str | None:
    lowered = message.casefold()
    if not any(
        marker in lowered
        for marker in ("makasih", "terima kasih", "thank you", "thanks")
    ):
        return None
    if language == "id":
        return "Sama-sama! Kalau mau mencari tempat lain, tinggal bilang saja."
    return "You're welcome! Tell me what kind of place you want to find next."


def _safe_general_fallback(
    message: str,
    language: ChatLanguage,
) -> str | None:
    if not _is_obvious_general(message):
        return None

    lowered = message.casefold()
    asks_capability = any(
        marker in lowered
        for marker in (
            "bisa apa",
            "siapa kamu",
            "what can you do",
            "who are you",
        )
    )
    is_thanks = any(
        marker in lowered
        for marker in ("makasih", "terima kasih", "thank you", "thanks")
    )
    if language == "id":
        if is_thanks:
            return "Sama-sama! Kalau mau mencari tempat lain, tinggal bilang saja."
        if asks_capability:
            return "Saya membantu mencari tempat terverifikasi dari Google Maps."
        return "Hai! Ada tempat yang ingin kamu cari?"
    if is_thanks:
        return "You're welcome! Tell me what kind of place you want to find next."
    if asks_capability:
        return "I help find verified places using Google Maps data."
    return "Hi! Is there a place you would like to find?"


def _generic_general_fallback(language: ChatLanguage) -> str:
    if language == "id":
        return "Pesan diterima. Saya bisa membantu mencari tempat terverifikasi."
    return "Message received. I can help find verified places."


def _extract_explicit_location(message: str) -> str | None:
    for pattern in _LOCATION_PATTERNS:
        match = pattern.search(message)
        if not match:
            continue
        candidate = match.group(1).strip(" .,!?\t\r\n")
        if candidate.casefold() not in _NON_LOCATIONS and len(candidate) >= 2:
            return candidate
    return None


def _verified_location(location: str | None, message: str) -> str | None:
    if not location:
        return None
    normalized_location = " ".join(location.casefold().split())
    normalized_message = " ".join(message.casefold().split())
    return location if normalized_location in normalized_message else None


def _strip_action_and_location(message: str) -> str:
    without_action = _ACTION_PREFIX.sub("", message.strip())
    for pattern in _LOCATION_PATTERNS:
        match = pattern.search(without_action)
        if match and match.group(1).strip(" .,!?\t\r\n").casefold() not in _NON_LOCATIONS:
            without_action = without_action[: match.start()]
            break
    return without_action.strip(" .,!?\t\r\n")


def _build_search_query(
    search_terms: str,
    location: str | None,
    language: ChatLanguage,
) -> str:
    terms = search_terms.strip()
    if not location or location.casefold() in terms.casefold():
        return terms
    connector = "di" if language == "id" else "near"
    return f"{terms} {connector} {location}"


def _clarification_message(language: ChatLanguage) -> str:
    if language == "id":
        return "Di kota atau area mana saya harus mencari?"
    return "Which city or area should I search in?"


def _missing_refinement_context_message(
    refinements: RefinementFlags, language: ChatLanguage
) -> str:
    if language == "id":
        if refinements.cheaper:
            return "Tempat atau jenis usaha apa yang ingin Anda cari dengan harga lebih terjangkau?"
        return "Jenis tempat apa yang ingin Anda cari?"
    if refinements.cheaper:
        return "Which type of place would you like me to find at a lower price?"
    return "Which type of place would you like to search for?"


def _unsupported_message(language: ChatLanguage) -> str:
    if language == "id":
        return "Saya hanya dapat membantu percakapan singkat dan pencarian tempat."
    return "I can only help with concise conversation and place searches."


def _result_message(count: int, query: str, language: ChatLanguage) -> str:
    if count == 0:
        if language == "id":
            return "Saya tidak menemukan tempat yang cocok untuk pencarian tersebut."
        return "I couldn't find matching places for that search."
    if language == "id":
        return f"Saya menemukan {count} {query}."
    return f"I found {count} {query}."


def _cheaper_result_message(
    count: int, search_terms: str, location: str | None, language: ChatLanguage
) -> str:
    loc_suffix = f" di sekitar {location}" if location else ""
    if language == "id":
        return f"Berdasarkan tingkat harga yang tersedia di Google Maps, saya menemukan {count} opsi {search_terms} yang cenderung lebih terjangkau{loc_suffix}."
    return f"Based on the price level available in Google Maps, I found {count} more affordable options."


def _higher_rated_message(language: ChatLanguage) -> str:
    if language == "id":
        return "Berikut opsi dengan rating tertinggi dari hasil yang tersedia."
    return "Here are the highest rated options from available results."


def _resolve_place_reference(
    context: SearchContext | None,
    reference: str | None,
    selected_index: int | None,
) -> PlaceReference | None:
    if context is None or not context.last_places:
        return None
    if selected_index is not None:
        index = selected_index - 1
        return context.last_places[index] if 0 <= index < len(context.last_places) else None
    if not reference:
        return context.last_places[0] if len(context.last_places) == 1 else None
    normalized = _normalize_name(reference)
    exact = [place for place in context.last_places if _normalize_name(place.name) == normalized]
    if len(exact) == 1:
        return exact[0]
    partial = [
        place for place in context.last_places
        if normalized in _normalize_name(place.name) or _normalize_name(place.name) in normalized
    ]
    return partial[0] if len(partial) == 1 else None


def _normalize_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()


def _is_open_24_hours(place: Place) -> bool:
    for hours in (place.current_opening_hours, place.regular_opening_hours):
        if not isinstance(hours, dict):
            continue
        periods = hours.get("periods")
        if not isinstance(periods, list):
            continue
        for period in periods:
            if not isinstance(period, dict):
                continue
            opened = period.get("open")
            closed = period.get("close")
            if isinstance(opened, dict) and closed is None:
                day = opened.get("day")
                hour = opened.get("hour", 0)
                minute = opened.get("minute", 0)
                if day == 0 and hour == 0 and minute == 0:
                    return True
    return False


def _detail_message(
    place: Place,
    detail: RequestedDetail,
    language: ChatLanguage,
) -> str:
    if detail in {RequestedDetail.CLOSING_TIME, RequestedDetail.OPENING_HOURS}:
        closing = _next_close_time(place)
        if closing:
            return (
                f"{place.name} tercatat tutup pada {closing}."
                if language == "id"
                else f"{place.name} is listed as closing at {closing}."
            )
        return (
            f"Saya menemukan {place.name}, tetapi Google Maps tidak menyediakan waktu tutup terverifikasi saat ini."
            if language == "id"
            else f"I found {place.name}, but Google Maps does not currently provide a verified closing time."
        )
    if detail == RequestedDetail.ADDRESS:
        return (
            f"Alamat {place.name}: {place.address or 'tidak tersedia'}."
            if language == "id"
            else f"{place.name}'s address is {place.address or 'unavailable'}."
        )
    if detail == RequestedDetail.RATING:
        rating = f"{place.rating:.1f}" if place.rating is not None else ("tidak tersedia" if language == "id" else "unavailable")
        return f"Rating {place.name}: {rating}." if language == "id" else f"{place.name} has a rating of {rating}."
    if detail == RequestedDetail.DIRECTIONS:
        return (
            f"Gunakan tombol Directions untuk menuju {place.name}."
            if language == "id"
            else f"Use the Directions action to navigate to {place.name}."
        )
    return f"{place.name}."


def _next_close_time(place: Place) -> str | None:
    for hours in (place.current_opening_hours, place.regular_opening_hours):
        if not isinstance(hours, dict):
            continue
        next_close = hours.get("nextCloseTime")
        if isinstance(next_close, str) and next_close.strip():
            return next_close.strip()
        descriptions = hours.get("weekdayDescriptions")
        if isinstance(descriptions, list) and descriptions:
            return None
    return None


def _haversine_meters(
    lat1: float, lng1: float, lat2: float, lng2: float
) -> float:
    radius = 6_371_000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lng2 - lng1)
    a = (
        math.sin(d_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2
    )
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _nearest_clarification_message(language: ChatLanguage) -> str:
    return (
        "Saya memerlukan lokasi Anda atau titik acuan spesifik untuk menentukan tempat terdekat."
        if language == "id"
        else "I need your current location or a specific landmark to determine the nearest place."
    )


def _no_24_hour_message(language: ChatLanguage) -> str:
    return (
        "Saya belum dapat memverifikasi tempat yang buka 24 jam dari hasil ini."
        if language == "id"
        else "I could not verify any of these places as open 24 hours."
    )


def _unmatched_place_message(language: ChatLanguage) -> str:
    return (
        "Saya tidak dapat mencocokkan tempat itu dengan hasil terbaru. Sebutkan nama atau nomor hasilnya."
        if language == "id"
        else "I could not match that place to the latest results. Please mention its name or result number."
    )
